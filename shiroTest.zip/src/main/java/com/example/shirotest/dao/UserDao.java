package com.example.shirotest.dao;

import com.example.shirotest.entity.Perms;
import com.example.shirotest.entity.Role;
import com.example.shirotest.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface UserDao {
    void save(User user);
    User findByUsername(String username);

    //根据用户名查询所有角色
    User findRolesByUserName(String username);

    //根据角色id查询权限集合
    Role findPermByRoleId(String id);
    //根据角色id查询权限集合
    List<Perms> findPermsByRoleId2(String id);

}
