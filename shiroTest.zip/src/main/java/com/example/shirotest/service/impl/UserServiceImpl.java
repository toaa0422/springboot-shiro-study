package com.example.shirotest.service.impl;

import com.example.shirotest.dao.UserDao;
import com.example.shirotest.entity.Perms;
import com.example.shirotest.entity.Role;
import com.example.shirotest.service.UserService;
import com.example.shirotest.entity.User;
import com.example.shirotest.util.SaltUtil;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired(required = false)
    private UserDao userDao;

    @Override
    public void register(User user) {
        String salt = SaltUtil.getSalt(8);
        user.setSalt(salt);
        Md5Hash md5Hash = new Md5Hash(user.getPassword(), salt, 1024);
        user.setPassword(md5Hash.toHex());
        userDao.save(user);

//        Md5Hash md5Hash = new Md5Hash(user.getPassword(), salt, 1024);
//        user.setPassword(md5Hash.toHex());
//        userDao.save(user);

    }

    @Override
    public User findByUsername(String username) {
        return userDao.findByUsername(username);
    }

    @Override
    public User findRoleByUsername(String username) {
        return userDao.findRolesByUserName(username);
    }

//    @Override
//    public Role findPermByRoleId(String id) {
//        return userDao.findPermByRoleId(id);
//    }

//    @Override
//    public List<Perms> findPermsByRoleId2(String id) {
//        return userDao.findPermsByRoleId2(id);
//    }

//    public User findRolesByUserName(String username) {
//        return userDao.findRolesByUserName(username);
//    }

}
