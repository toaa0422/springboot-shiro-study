package com.example.shirotest.realm;

import com.example.shirotest.entity.Perms;
import com.example.shirotest.entity.User;
import com.example.shirotest.service.UserService;
import com.example.shirotest.util.ApplicationContextUtil;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.util.List;

public class CustomerRealm extends AuthorizingRealm {


    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String principal = (String) principalCollection.getPrimaryPrincipal();
        //获取UserService对象
        UserService userService = (UserService) ApplicationContextUtil.getBean("userService");
        //System.out.println(userService);
        //基于角色授权
        User user = userService.findRoleByUsername(principal);
        System.out.println("user======="+user);
        if (!CollectionUtils.isEmpty(user.getRoles())) {
            SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
            user.getRoles().forEach(role ->{
                info.addRole(role.getName());
                /*Role role2 = userService.findPermByRoleId(role.getId());
                System.out.println("role2======"+role2);
                if (!CollectionUtils.isEmpty(role2.getPerms())) {
                    role2.getPerms().forEach(perm -> info.addStringPermission(perm.getName()));
                }*/

                //权限信息
                List<Perms> perms = userService.findPermsByRoleId2(role.getId());
                System.out.println("perms========"+perms);
                if(!CollectionUtils.isEmpty(perms) && perms.get(0)!=null ){
                    perms.forEach(perm->{
                        info.addStringPermission(perm.getName());
                    });
                }
            });
            return info;
        }
        return null;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        String principal = (String) authenticationToken.getPrincipal();
        //获取UserService对象
        UserService userService = (UserService) ApplicationContextUtil.getBean("userService");
        //System.out.println(userService);
        User user = userService.findByUsername(principal);
        if (!ObjectUtils.isEmpty(user)) {
            return new SimpleAuthenticationInfo(user.getUsername(), user.getPassword(), ByteSource.Util.bytes(user.getSalt()), this.getName());
        }
        return null;
    }
}
